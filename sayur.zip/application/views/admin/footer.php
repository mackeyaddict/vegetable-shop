<div class="container-fluid" style="background-color:  #487877 ;">
    <div class="container mt-5">
        <div class="mx-5 text-white">
            <div class="col-md-12 col-sm-12 col-xs-12 text-center" style="padding: 40px;">
                <h3>Made With Love by Students of Bina Insani University</h3>
            </div>
            <div class="row mb-4">
                <div class="col-md-3 col-sm-3 col-xs-3">
                    <div class="footer-text pull-center">
                        <div class="d-flex">
                            <img class="image-fluid" src="<?php echo base_url() . 'assets/image/logo-biu.png' ?>"
                                alt="">
                        </div>
                    </div>
                </div>
                <div class="col-md-1 col-sm-1 col-xs-1" style="border-left:1px solid #afdebc;height:150px"></div>
                <div class="col-md-4 col-sm-4 col-xs-4">
                    <h5 class="heading">Purpose</h5>
                    <p>Website ini dibuat dengan tujuan memenuhi tugas besar Pemrograman Web Lanjut dan juga ditujukan
                        mendigitalisasi UMKM khususnya penjualaan sayur di toko Sayur Doel</p>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-4 text-end">
                    <h5 class="heading">Our Team</h5>
                    <ul style="list-style-type:none;">
                        <li>Arya Bima Aditya</li>
                        <li>Bagas Ari Darmawan</li>
                        <li>Engkos Kosasih</li>
                        <li>Dimas Muzakki</li>
                        <li>Naufal Yusuf Fauzan</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-1 col-sm-1 col-xs-1" style="border-bottom:1px solid #afdebc;width:1300px"></div>
        <div class="row p-4" style="font-size:10px;">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="text-center text-white">
                    <p>2023 &#169; Pemrograman Web Lanjut</p>
                </div>
            </div>
        </div>
    </div>
</div>